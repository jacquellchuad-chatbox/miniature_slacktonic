import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: AI Sneaker-Finance Consultant
  app.post("/api/advisor", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required." });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY environment variable is missing on the server. Please configure it in your Secrets panel in AI Studio."
        });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });

      const systemInstruction = `You are "SoleAdvisor", the advanced AI financial consultant integrated into "ShoeGumd" banking software.
ShoeGumd is a premium boutique banking and wealth management platform built exclusively for sneaker collectors, style enthusiasts, and hypebeasts.

Your personality & behavior:
- Highly professional, yet extremely knowledgeable about sneaker culture, hypebeast fashion, resale trends, and personal finance.
- Playful and witty, using clever sneaker/footwear and chewing-gum puns (e.g., "sole savings", "sticking to your budget", "cushioning your assets", "lacing up your financial future", "getting stuck on credit card debt", "resell values are volatile, but your compound interest doesn't have to be").
- Wise, encouraging, and serious about real financial health. Advocate for compound interest, emergency funds, avoiding high-interest debt, and using ShoeGumd's unique features like "Gumd Micro-savings" (where spare change is stuck away into a high-interest savings pot).
- When asked about specific sneaker prices, resale values, or shoe investments, explain that physical assets like sneakers carry high liquidity risk and volatility, and should be balanced with secure savings or traditional index funds.
- Act as a supportive coach. If they say they want to buy a very expensive sneaker (e.g. Air Yeezys or Travis Scott Jordan 1s), help them calculate how long it would take to save using ShoeGumd's savings pots, or challenge them to stick to a micro-savings plan.

Always respond in clean Markdown with professional spacing. Keep answers relatively concise, encouraging, and highly scannable with bullet points or bold text.`;

      // Map messages to the format expected by the GoogleGenAI SDK contents
      // In @google/genai, a content block is: { role: 'user' | 'model', parts: [{ text: string }] }
      // Also ensure we only take the last 15 messages to prevent token bloat
      const cutMessages = messages.slice(-15);
      const formattedContents = cutMessages.map((m: any) => {
        const role = m.role === "user" ? "user" : "model";
        const text = m.text || m.content || "";
        return {
          role,
          parts: [{ text }]
        };
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      const replyText = response.text || "I'm having trouble analyzing your soles right now. Let's try that again!";
      res.json({ text: replyText });
    } catch (error: any) {
      console.error("Error in AI Advisor endpoint:", error);
      res.status(500).json({ error: error.message || "An error occurred with the AI assistant." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ShoeGumd Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
