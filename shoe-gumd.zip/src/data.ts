import { Transaction, SavingsGoal, SneakerPortfolioItem, MarketSneaker } from "./types";

export const initialTransactions: Transaction[] = [
  {
    id: "tx-1",
    date: "2026-07-14",
    description: "Sold Yeezy Boost 350 Zebra",
    amount: 390,
    type: "income",
    category: "grails",
    shoeModel: "Yeezy Boost 350 V2 'Zebra'"
  },
  {
    id: "tx-2",
    date: "2026-07-13",
    description: "ShoeGumd Cash Deposit",
    amount: 1500,
    type: "income",
    category: "deposit"
  },
  {
    id: "tx-3",
    date: "2026-07-12",
    description: "Sneaker Politics Store Purchase",
    amount: 220,
    type: "expense",
    category: "retail"
  },
  {
    id: "tx-4",
    date: "2026-07-10",
    description: "Gumd Micro-Savings Autodeposit",
    amount: 14.50,
    type: "income", // deposits into the vault show up as income for the vault
    category: "gumd_saved"
  },
  {
    id: "tx-5",
    date: "2026-07-09",
    description: "Transferred to @hype_kicks",
    amount: 450,
    type: "expense",
    category: "transfer"
  }
];

export const initialSavingsGoals: SavingsGoal[] = [
  {
    id: "goal-1",
    name: "Air Jordan 1 'Chicago' Fund",
    target: 1250,
    current: 850,
    image: "🔴",
    deadline: "2026-09-01",
    isCompleted: false
  },
  {
    id: "goal-2",
    name: "Travis Scott Reverse Mocha Fund",
    target: 1150,
    current: 400,
    image: "🟤",
    deadline: "2026-11-15",
    isCompleted: false
  },
  {
    id: "goal-3",
    name: "Gumd Rainy Day Sole Reserve",
    target: 500,
    current: 500,
    image: "🍬",
    deadline: "2026-08-01",
    isCompleted: true
  }
];

export const initialPortfolio: SneakerPortfolioItem[] = [
  {
    id: "port-1",
    name: "Air Jordan 1 Retro High 'Chicago'",
    purchasePrice: 900,
    currentPrice: 1250,
    size: 10.5,
    condition: "DS (Deadstock)",
    image: "🔴",
    sku: "555088-101",
    purchaseDate: "2025-12-15"
  },
  {
    id: "port-2",
    name: "Adidas Yeezy Boost 350 V2 'Zebra'",
    purchasePrice: 320,
    currentPrice: 380,
    size: 11,
    condition: "VNDS (Very Near Deadstock)",
    image: "🏁",
    sku: "CP9654",
    purchaseDate: "2026-02-10"
  }
];

export const trendingMarketSneakers: MarketSneaker[] = [
  {
    id: "m-1",
    name: "AJ1 Retro High OG 'Chicago'",
    sku: "555088-101",
    retailPrice: 180,
    marketPrice: 1250,
    prevMarketPrice: 1180,
    image: "🔴",
    rarity: "Grail",
    color: "from-red-600 to-white"
  },
  {
    id: "m-2",
    name: "SB Dunk Low 'Chunky Dunky'",
    sku: "CC1655-100",
    retailPrice: 110,
    marketPrice: 1650,
    prevMarketPrice: 1720,
    image: "🐮",
    rarity: "Hyperstrike",
    color: "from-sky-400 via-green-400 to-yellow-400"
  },
  {
    id: "m-3",
    name: "Yeezy Boost 350 V2 'Zebra'",
    sku: "CP9654",
    retailPrice: 220,
    marketPrice: 380,
    prevMarketPrice: 375,
    image: "🏁",
    rarity: "Common",
    color: "from-zinc-100 via-zinc-800 to-zinc-100"
  },
  {
    id: "m-4",
    name: "Travis Scott Reverse Mocha AJ1",
    sku: "DM7866-162",
    retailPrice: 150,
    marketPrice: 1150,
    prevMarketPrice: 1090,
    image: "🟤",
    rarity: "Grail",
    color: "from-amber-900 via-stone-100 to-stone-300"
  },
  {
    id: "m-5",
    name: "MSCHF x INRI 'Jesus Shoes'",
    sku: "MSCHF-JS97",
    retailPrice: 1425,
    marketPrice: 3200,
    prevMarketPrice: 3400,
    image: "💧",
    rarity: "Hyperstrike",
    color: "from-cyan-100 via-blue-500 to-teal-500"
  },
  {
    id: "m-6",
    name: "Nike SB Dunk Low 'Tiffany'",
    sku: "304292-402",
    retailPrice: 65,
    marketPrice: 2450,
    prevMarketPrice: 2380,
    image: "💎",
    rarity: "Grail",
    color: "from-teal-300 via-black to-zinc-900"
  }
];
