export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: "income" | "expense";
  category: "grails" | "retail" | "gumd_saved" | "transfer" | "general" | "deposit";
  shoeModel?: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  target: number;
  current: number;
  image: string;
  deadline: string;
  isCompleted: boolean;
}

export interface SneakerPortfolioItem {
  id: string;
  name: string;
  purchasePrice: number;
  currentPrice: number;
  size: number;
  condition: string;
  image: string;
  sku: string;
  purchaseDate: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: string;
}

export interface MarketSneaker {
  id: string;
  name: string;
  sku: string;
  retailPrice: number;
  marketPrice: number;
  prevMarketPrice: number;
  image: string;
  rarity: "Common" | "Rare" | "Grail" | "Hyperstrike";
  color: string;
}
