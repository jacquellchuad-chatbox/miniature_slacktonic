import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LayoutGrid, 
  Briefcase, 
  Landmark, 
  Sparkles, 
  History, 
  TrendingUp, 
  Wallet, 
  Heart, 
  Coins, 
  Percent, 
  Info, 
  TrendingDown, 
  CheckCircle2, 
  Flame, 
  Candy, 
  HelpCircle,
  ChevronRight
} from "lucide-react";

import { 
  Transaction, 
  SavingsGoal, 
  SneakerPortfolioItem, 
  MarketSneaker 
} from "./types";

import { 
  initialTransactions, 
  initialSavingsGoals, 
  initialPortfolio, 
  trendingMarketSneakers 
} from "./data";

import GumdCard from "./components/GumdCard";
import SoleAdvisor from "./components/SoleAdvisor";
import PortfolioManager from "./components/PortfolioManager";
import SavingsGoals from "./components/SavingsGoals";
import TransactionHistory from "./components/TransactionHistory";

export default function App() {
  // Tabs: overview | portfolio | savings | advisor | ledger
  const [activeTab, setActiveTab] = useState<"overview" | "portfolio" | "savings" | "advisor" | "ledger">("overview");

  // Core Financial States
  const [checkingBalance, setCheckingBalance] = useState<number>(3500);
  const [portfolio, setPortfolio] = useState<SneakerPortfolioItem[]>(initialPortfolio);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(initialSavingsGoals);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [marketSneakers, setMarketSneakers] = useState<MarketSneaker[]>(trendingMarketSneakers);
  const [gumdActive, setGumdActive] = useState<boolean>(true);
  const [isFrozen, setIsFrozen] = useState<boolean>(false);
  const [userProfileName, setUserProfileName] = useState<string>("SNEAKERHEAD_45");

  // Persistence: Load from localStorage on mount
  useEffect(() => {
    const savedBalance = localStorage.getItem("sg_balance");
    const savedPortfolio = localStorage.getItem("sg_portfolio");
    const savedGoals = localStorage.getItem("sg_goals");
    const savedTx = localStorage.getItem("sg_transactions");
    const savedMarket = localStorage.getItem("sg_market");
    const savedGumd = localStorage.getItem("sg_gumd");
    const savedName = localStorage.getItem("sg_username");

    if (savedBalance) setCheckingBalance(parseFloat(savedBalance));
    if (savedPortfolio) setPortfolio(JSON.parse(savedPortfolio));
    if (savedGoals) setSavingsGoals(JSON.parse(savedGoals));
    if (savedTx) setTransactions(JSON.parse(savedTx));
    if (savedMarket) setMarketSneakers(JSON.parse(savedMarket));
    if (savedGumd) setGumdActive(savedGumd === "true");
    if (savedName) setUserProfileName(savedName);
  }, []);

  // Save states to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("sg_balance", checkingBalance.toString());
    localStorage.setItem("sg_portfolio", JSON.stringify(portfolio));
    localStorage.setItem("sg_goals", JSON.stringify(savingsGoals));
    localStorage.setItem("sg_transactions", JSON.stringify(transactions));
    localStorage.setItem("sg_market", JSON.stringify(marketSneakers));
    localStorage.setItem("sg_gumd", gumdActive.toString());
    localStorage.setItem("sg_username", userProfileName);
  }, [checkingBalance, portfolio, savingsGoals, transactions, marketSneakers, gumdActive, userProfileName]);

  // Derived Values
  const portfolioValuation = portfolio.reduce((acc, item) => acc + item.currentPrice, 0);
  const savingsPotsValue = savingsGoals.reduce((acc, g) => acc + g.current, 0);
  const totalNetWorth = checkingBalance + portfolioValuation + savingsPotsValue;

  // Handlers
  const handleBuySneaker = (sneaker: MarketSneaker, size: number) => {
    if (isFrozen) {
      alert("❌ Transaction Denied: Your ShoeGumd Card is frozen. Unfreeze it to buy grails!");
      return;
    }

    if (checkingBalance < sneaker.marketPrice) {
      alert(`❌ Insufficient Funds: This sneaker costs $${sneaker.marketPrice} but you only have $${checkingBalance} in your checking account.`);
      return;
    }

    const price = sneaker.marketPrice;
    
    // Deduct Balance
    setCheckingBalance((prev) => prev - price);

    // Add to Portfolio
    const newItem: SneakerPortfolioItem = {
      id: `item-${Date.now()}`,
      name: sneaker.name,
      purchasePrice: price,
      currentPrice: price,
      size,
      condition: "DS (Deadstock)",
      image: sneaker.image,
      sku: sneaker.sku,
      purchaseDate: new Date().toISOString().split('T')[0]
    };
    setPortfolio((prev) => [newItem, ...prev]);

    // Create Transaction
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Bought ${sneaker.name}`,
      amount: price,
      type: "expense",
      category: "grails",
      shoeModel: sneaker.name
    };

    // Calculate Gumd Spare Change Round up if active
    let resultingTx = [newTx];
    if (gumdActive) {
      const rounded = Math.ceil(price);
      const spareChange = rounded - price;
      if (spareChange > 0) {
        // Apply spare change to the first incomplete goal
        const firstGoalIdx = savingsGoals.findIndex(g => !g.isCompleted);
        if (firstGoalIdx !== -1) {
          const updatedGoals = [...savingsGoals];
          const targetGoal = updatedGoals[firstGoalIdx];
          
          setCheckingBalance((prev) => parseFloat((prev - spareChange).toFixed(2)));
          targetGoal.current = parseFloat((targetGoal.current + spareChange).toFixed(2));
          if (targetGoal.current >= targetGoal.target) {
            targetGoal.isCompleted = true;
          }
          setSavingsGoals(updatedGoals);

          resultingTx.push({
            id: `gumd-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            description: `Gumd round-up to ${targetGoal.name}`,
            amount: parseFloat(spareChange.toFixed(2)),
            type: "income",
            category: "gumd_saved"
          });
        }
      }
    }

    setTransactions((prev) => [...resultingTx, ...prev]);
  };

  const handleSellSneaker = (itemId: string) => {
    if (isFrozen) {
      alert("❌ Transaction Denied: Your ShoeGumd Card is frozen. Unfreeze it to sell assets!");
      return;
    }

    const item = portfolio.find(i => i.id === itemId);
    if (!item) return;

    const sellValue = item.currentPrice;

    // Refund checking
    setCheckingBalance((prev) => prev + sellValue);

    // Remove from portfolio
    setPortfolio((prev) => prev.filter(i => i.id !== itemId));

    // Create Transaction
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Liquidated ${item.name}`,
      amount: sellValue,
      type: "income",
      category: "grails",
      shoeModel: item.name
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleToggleGumd = () => {
    setGumdActive(!gumdActive);
  };

  const handleDepositGoal = (goalId: string, amount: number) => {
    if (checkingBalance < amount) return;

    // Deduct checking
    setCheckingBalance((prev) => prev - amount);

    // Update Goal
    setSavingsGoals((prev) => {
      return prev.map((g) => {
        if (g.id === goalId) {
          const updatedCurrent = g.current + amount;
          return {
            ...g,
            current: updatedCurrent,
            isCompleted: updatedCurrent >= g.target
          };
        }
        return g;
      });
    });

    const goal = savingsGoals.find(g => g.id === goalId);
    // Create transaction
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Cushion Deposit to ${goal?.name || "Pot"}`,
      amount,
      type: "expense",
      category: "gumd_saved"
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleAddGoal = (name: string, target: number) => {
    const shoeImages = ["🔴", "🟤", "🏁", "🐮", "💧", "💎", "👟"];
    const randomImg = shoeImages[Math.floor(Math.random() * shoeImages.length)];

    const newGoal: SavingsGoal = {
      id: `goal-${Date.now()}`,
      name,
      target,
      current: 0,
      image: randomImg,
      deadline: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 months deadline
      isCompleted: false
    };

    setSavingsGoals((prev) => [...prev, newGoal]);
  };

  const handleDeleteGoal = (goalId: string) => {
    const goal = savingsGoals.find(g => g.id === goalId);
    if (!goal) return;

    // Refund any saved portion back to checking
    if (goal.current > 0) {
      setCheckingBalance((prev) => prev + goal.current);
      
      const refundTx: Transaction = {
        id: `tx-${Date.now()}-refund`,
        date: new Date().toISOString().split('T')[0],
        description: `Refunded saved portion from ${goal.name}`,
        amount: goal.current,
        type: "income",
        category: "deposit"
      };
      setTransactions((prev) => [refundTx, ...prev]);
    }

    setSavingsGoals((prev) => prev.filter(g => g.id !== goalId));
  };

  const handleTransfer = (handle: string, amount: number, description: string) => {
    if (isFrozen) {
      alert("❌ Transaction Denied: Your ShoeGumd Card is frozen. Unfreeze it to transfer funds!");
      return;
    }

    if (checkingBalance < amount) return;

    // Deduct checking
    setCheckingBalance((prev) => prev - amount);

    // Create transaction
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Transferred to ${handle} (${description})`,
      amount,
      type: "expense",
      category: "transfer"
    };

    let resultingTx = [newTx];
    // Calculate Gumd Spare change on expense
    if (gumdActive) {
      const rounded = Math.ceil(amount);
      const spareChange = rounded - amount;
      if (spareChange > 0) {
        const firstGoalIdx = savingsGoals.findIndex(g => !g.isCompleted);
        if (firstGoalIdx !== -1) {
          const updatedGoals = [...savingsGoals];
          const targetGoal = updatedGoals[firstGoalIdx];

          setCheckingBalance((prev) => parseFloat((prev - spareChange).toFixed(2)));
          targetGoal.current = parseFloat((targetGoal.current + spareChange).toFixed(2));
          if (targetGoal.current >= targetGoal.target) {
            targetGoal.isCompleted = true;
          }
          setSavingsGoals(updatedGoals);

          resultingTx.push({
            id: `gumd-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            description: `Gumd round-up to ${targetGoal.name}`,
            amount: parseFloat(spareChange.toFixed(2)),
            type: "income",
            category: "gumd_saved"
          });
        }
      }
    }

    setTransactions((prev) => [...resultingTx, ...prev]);
  };

  const handleDepositCash = (amount: number) => {
    setCheckingBalance((prev) => prev + amount);

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: "ShoeGumd Cash Deposit Simulator",
      amount,
      type: "income",
      category: "deposit"
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleTriggerMarketFluctuation = () => {
    // Generate randomized multipliers between -15% and +20% for each shoe
    const updatedMarket = marketSneakers.map((shoe) => {
      // 30% chance of drop, 70% chance of spike/growth
      const isDrop = Math.random() < 0.35;
      const percentChange = isDrop 
        ? parseFloat((Math.random() * -0.12).toFixed(4)) // up to -12% drop
        : parseFloat((Math.random() * 0.18).toFixed(4)); // up to +18% growth

      const newPrice = Math.max(10, Math.round(shoe.marketPrice * (1 + percentChange)));
      
      return {
        ...shoe,
        prevMarketPrice: shoe.marketPrice,
        marketPrice: newPrice
      };
    });

    setMarketSneakers(updatedMarket);

    // Also update our portfolio items so that the user's wealth dynamically shifts!
    setPortfolio((prevPortfolio) => {
      return prevPortfolio.map((item) => {
        // Find matching SKU in the updated market
        const match = updatedMarket.find((m) => m.sku === item.sku);
        if (match) {
          return {
            ...item,
            currentPrice: match.marketPrice
          };
        }
        return item;
      });
    });

    // Append notification transaction
    const alertTx: Transaction = {
      id: `alert-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: "⚠️ Sneaker Hype Fluctuations Registered!",
      amount: 0,
      type: "income",
      category: "general"
    };
    setTransactions((prev) => [alertTx, ...prev]);
  };

  const resetAllAppState = () => {
    if (confirm("⚠️ Warning: This will clear all custom savings pots, sneaker portfolio items, and transactions from your browser, resetting ShoeGumd back to its pristine default state. Proceed?")) {
      localStorage.clear();
      setCheckingBalance(3500);
      setPortfolio(initialPortfolio);
      setSavingsGoals(initialSavingsGoals);
      setTransactions(initialTransactions);
      setMarketSneakers(trendingMarketSneakers);
      setGumdActive(true);
      setIsFrozen(false);
      setUserProfileName("SNEAKERHEAD_45");
      setActiveTab("overview");
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 font-sans flex flex-col antialiased selection:bg-[#d4ff3f] selection:text-zinc-950">
      
      {/* Decorative Elite Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f29370f_1px,transparent_1px),linear-gradient(to_bottom,#1f29370f_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Top Brand Navigation Header */}
      <header className="border-b border-zinc-900 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-3">
            {/* Playful chewing-gum pink sphere holding custom sneaker icon styling */}
            <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-pink-400 via-rose-300 to-[#d4ff3f] shadow-[0_0_15px_rgba(244,114,182,0.3)]">
              <span className="text-zinc-950 font-extrabold text-lg select-none">S</span>
              {/* Spinning micro halo */}
              <div className="absolute -inset-0.5 rounded-xl border border-white/20 animate-spin-slow"></div>
            </div>

            <div>
              <div className="flex items-baseline gap-1.5">
                <h1 className="text-lg font-display font-extrabold tracking-tight text-white">ShoeGumd</h1>
                <span className="text-[10px] font-mono text-[#d4ff3f] uppercase tracking-widest font-bold">Banking</span>
              </div>
              <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Laced with high savings soles</p>
            </div>
          </div>

          {/* Interactive User Info Widget */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-zinc-900/80 border border-zinc-800 px-3 py-1.5 rounded-xl">
              <div className="w-2 h-2 rounded-full bg-[#d4ff3f] animate-pulse"></div>
              <input 
                type="text" 
                value={userProfileName} 
                onChange={(e) => setUserProfileName(e.target.value.toUpperCase().replace(/\s+/g, '_').slice(0, 16))}
                className="bg-transparent border-none text-xs font-mono font-semibold text-zinc-300 focus:outline-none w-28 uppercase"
                title="Click to rename profile handle"
              />
            </div>

            <button
              onClick={resetAllAppState}
              className="text-[10px] font-mono text-zinc-600 hover:text-red-400 transition-colors bg-zinc-900/40 hover:bg-red-950/20 px-2.5 py-1.5 rounded-lg border border-zinc-850 hover:border-red-900/30"
              title="Reset application back to default start state"
            >
              Reset Account
            </button>
          </div>

        </div>
      </header>

      {/* Checking Balance & Combined Net Worth Banner */}
      <section className="bg-zinc-950 border-b border-zinc-900 px-6 py-8 relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-64 h-24 rounded-full bg-lime-500/5 filter blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-64 h-24 rounded-full bg-pink-500/5 filter blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 relative z-10">
          
          {/* Main Net Worth */}
          <div className="md:col-span-2">
            <div className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest">Cumulative Net Worth</div>
            <div className="text-4xl font-display font-black tracking-tight text-white mt-1.5" id="cumulative-networth">
              ${totalNetWorth.toLocaleString()}
            </div>
            <p className="text-xs text-zinc-400 mt-2 flex items-center gap-1.5 font-mono">
              <span className="text-[#d4ff3f]">★</span>
              <span>Holding liquified checking cash, portfolio sneaker values, and savings pots</span>
            </p>
          </div>

          {/* Liquid Checking Account */}
          <div className="bg-zinc-900/40 border border-zinc-850 p-4 rounded-2xl flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-[10px] font-mono text-zinc-500 uppercase">Checking Checking</div>
                <div className="text-xl font-mono font-bold text-[#d4ff3f] mt-1" id="checking-balance">
                  ${checkingBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-[#d4ff3f]/10 text-[#d4ff3f]">
                <Wallet className="h-4 w-4" />
              </div>
            </div>
            <span className="text-[9px] font-mono text-zinc-600 mt-2">ACCOUNT #3320-9812-SG</span>
          </div>

          {/* Sneaker Assets Valuation */}
          <div className="bg-zinc-900/40 border border-zinc-850 p-4 rounded-2xl flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-[10px] font-mono text-zinc-500 uppercase">Sneaker Asset Wealth</div>
                <div className="text-xl font-mono font-bold text-white mt-1">
                  ${portfolioValuation.toLocaleString()}
                </div>
              </div>
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                <Briefcase className="h-4 w-4" />
              </div>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-[9px] font-mono text-zinc-600">HELD IN VAULT: {portfolio.length} PAIRS</span>
              <span className="text-[9px] font-mono text-purple-400 font-bold">Resalable</span>
            </div>
          </div>

        </div>
      </section>

      {/* Main Core Dashboard & Module Panel */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-6 flex flex-col gap-6">
        
        {/* Module Sub-Navigation tabs */}
        <div className="flex overflow-x-auto gap-2 bg-zinc-950/65 p-1 rounded-2xl border border-zinc-850 self-start">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "overview"
                ? "bg-zinc-900 text-[#d4ff3f] border border-zinc-800"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <LayoutGrid className="h-4 w-4" />
            <span>Sole Overview</span>
          </button>

          <button
            onClick={() => setActiveTab("portfolio")}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "portfolio"
                ? "bg-zinc-900 text-[#d4ff3f] border border-zinc-800"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Briefcase className="h-4 w-4" />
            <span>Sneaker Portfolio ({portfolio.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("savings")}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "savings"
                ? "bg-zinc-900 text-[#d4ff3f] border border-zinc-800"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Landmark className="h-4 w-4" />
            <span>Sole Savings Pots</span>
          </button>

          <button
            onClick={() => setActiveTab("advisor")}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "advisor"
                ? "bg-zinc-900 text-[#d4ff3f] border border-zinc-800"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Sparkles className="h-4 w-4" />
            <span>SoleAdvisor AI</span>
          </button>

          <button
            onClick={() => setActiveTab("ledger")}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold uppercase flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "ledger"
                ? "bg-zinc-900 text-[#d4ff3f] border border-zinc-800"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <History className="h-4 w-4" />
            <span>Full Ledger</span>
          </button>
        </div>

        {/* Dynamic Panel Renderer with AnimatePresence */}
        <div className="flex-1 min-h-0 relative">
          <AnimatePresence mode="wait">
            {activeTab === "overview" && (
              <motion.div
                key="tab-overview"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 lg:grid-cols-3 gap-6"
              >
                
                {/* Left Side: Debit card visual & customizer */}
                <div className="lg:col-span-1 space-y-6">
                  <GumdCard 
                    cardHolder={userProfileName} 
                    isFrozen={isFrozen} 
                    onToggleFreeze={() => setIsFrozen(!isFrozen)} 
                    balance={checkingBalance}
                  />

                  {/* High interest banner card */}
                  <div className="p-5 rounded-3xl bg-zinc-950/40 border border-zinc-850 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-3 text-pink-400 font-mono text-3xl opacity-10">🍬</div>
                    <h3 className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Percent className="h-4 w-4 text-[#d4ff3f]" />
                      <span>Chewing Gum Yield (APY)</span>
                    </h3>
                    <p className="text-2xl font-mono font-extrabold text-[#d4ff3f] mt-1">4.80%</p>
                    <p className="text-[10px] text-zinc-400 mt-1 leading-normal">
                      Every dollar "stuck" (gummed) in your Sole Savings pots earns 4.80% annual percentage yield, backed by ShoeGumd's boutique high-yield liquidity pool.
                    </p>
                  </div>
                </div>

                {/* Right Side / Middle Column bento parts */}
                <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Savings Goals overview */}
                  <div className="bg-zinc-950/30 rounded-3xl border border-zinc-850 p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                          <Landmark className="h-4 w-4 text-pink-400" />
                          <span>Savings Pots Status</span>
                        </h3>
                        <button 
                          onClick={() => setActiveTab("savings")}
                          className="text-[10px] font-mono text-zinc-500 hover:text-zinc-300 flex items-center gap-1 uppercase"
                        >
                          <span>Manage</span>
                          <ChevronRight className="h-3 w-3" />
                        </button>
                      </div>

                      <div className="space-y-3.5">
                        {savingsGoals.slice(0, 2).map((goal) => {
                          const percentage = Math.min((goal.current / goal.target) * 100, 100);
                          return (
                            <div key={goal.id} className="space-y-1">
                              <div className="flex justify-between text-xs font-mono">
                                <span className="text-zinc-300 font-bold truncate pr-2">{goal.name}</span>
                                <span className="text-zinc-400 shrink-0">${goal.current} / ${goal.target}</span>
                              </div>
                              <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-850">
                                <div 
                                  className="h-full bg-[#d4ff3f] rounded-full" 
                                  style={{ width: `${percentage}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-zinc-900 flex justify-between items-center">
                      <div className="text-[10px] font-mono text-zinc-500">TOTAL SAVED IN SOLES:</div>
                      <div className="text-sm font-mono font-extrabold text-pink-400">${savingsPotsValue.toLocaleString()}</div>
                    </div>
                  </div>

                  {/* Quick SoleAdvisor Contact Box */}
                  <div className="bg-zinc-950/30 rounded-3xl border border-zinc-850 p-6 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-widest flex items-center gap-2 mb-3">
                        <Sparkles className="h-4 w-4 text-[#d4ff3f]" />
                        <span>Consult SoleAdvisor AI</span>
                      </h3>
                      <p className="text-[11px] text-zinc-400 leading-normal">
                        Your server-side Gemini 3.5 Assistant is synced. Get immediate sneaker valuations, portfolio evaluations, or clever savings strategies tailored for your budget!
                      </p>
                    </div>

                    <button
                      onClick={() => setActiveTab("advisor")}
                      className="mt-4 w-full py-2.5 rounded-xl bg-[#d4ff3f] hover:bg-lime-400 text-zinc-950 font-mono text-xs font-extrabold uppercase transition-all flex items-center justify-center gap-2"
                    >
                      <span>Lace up advisor chat</span>
                      <Sparkles className="h-3.5 w-3.5 animate-pulse" />
                    </button>
                  </div>

                  {/* Portfolio Valuation mini box */}
                  <div className="md:col-span-2 bg-zinc-950/30 rounded-3xl border border-zinc-850 p-6 flex flex-col justify-between">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                          <Briefcase className="h-4 w-4 text-purple-400" />
                          <span>Hype Asset Holdings</span>
                        </h3>
                        <p className="text-[10px] text-zinc-500 mt-1">Sneakers in portfolio evaluated at current marketplace index prices</p>
                      </div>
                      <button 
                        onClick={() => setActiveTab("portfolio")}
                        className="text-[10px] font-mono text-zinc-500 hover:text-zinc-300 flex items-center gap-1 uppercase"
                      >
                        <span>Marketplace</span>
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </div>

                    {/* Simple list of top portfolio item */}
                    {portfolio.length === 0 ? (
                      <div className="py-6 text-center text-zinc-600 font-mono text-xs border border-dashed border-zinc-850 rounded-2xl bg-zinc-950/10">
                        No portfolio assets. Invest some checking dollars in grail sneakers!
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {portfolio.slice(0, 4).map((item) => (
                          <div key={item.id} className="p-2.5 bg-zinc-950 border border-zinc-850 rounded-xl flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{item.image}</span>
                              <div>
                                <div className="text-[10px] font-mono font-bold text-zinc-200 line-clamp-1">{item.name}</div>
                                <div className="text-[8px] font-mono text-zinc-500">Size {item.size} • Bought ${item.purchasePrice}</div>
                              </div>
                            </div>
                            <span className="text-[10px] font-mono font-bold text-[#d4ff3f]">${item.currentPrice}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>

              </motion.div>
            )}

            {activeTab === "portfolio" && (
              <motion.div
                key="tab-portfolio"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-3xl mx-auto"
              >
                <PortfolioManager 
                  portfolio={portfolio} 
                  marketSneakers={marketSneakers} 
                  currentBalance={checkingBalance} 
                  onBuySneaker={handleBuySneaker} 
                  onSellSneaker={handleSellSneaker} 
                  onTriggerMarketFluctuation={handleTriggerMarketFluctuation}
                />
              </motion.div>
            )}

            {activeTab === "savings" && (
              <motion.div
                key="tab-savings"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-3xl mx-auto"
              >
                <SavingsGoals 
                  savingsGoals={savingsGoals} 
                  gumdActive={gumdActive} 
                  onToggleGumd={handleToggleGumd} 
                  onDepositGoal={handleDepositGoal} 
                  onAddGoal={handleAddGoal} 
                  onDeleteGoal={handleDeleteGoal} 
                  currentBalance={checkingBalance}
                />
              </motion.div>
            )}

            {activeTab === "advisor" && (
              <motion.div
                key="tab-advisor"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-3xl mx-auto"
              >
                <SoleAdvisor 
                  currentBalance={checkingBalance} 
                  portfolioValue={portfolioValuation} 
                  savingGoalsCount={savingsGoals.filter(g => !g.isCompleted).length}
                />
              </motion.div>
            )}

            {activeTab === "ledger" && (
              <motion.div
                key="tab-ledger"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-3xl mx-auto"
              >
                <TransactionHistory 
                  transactions={transactions} 
                  onTransfer={handleTransfer} 
                  onDeposit={handleDepositCash} 
                  currentBalance={checkingBalance}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </main>

      {/* Styled Human Footer with No Infostructural AI Clutter */}
      <footer className="border-t border-zinc-950 bg-zinc-950 py-6 text-center text-[10px] font-mono text-zinc-600">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <span>SHOE GUMD FINTECH CORPORATION © 2026</span>
          <span className="flex items-center gap-1 select-none">
            Cushioned with <Heart className="h-3 w-3 text-pink-400 fill-pink-400" /> for Sneaker Enthusia
          </span>
        </div>
      </footer>

    </div>
  );
}
