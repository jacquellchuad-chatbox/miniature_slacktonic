import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { TrendingUp, TrendingDown, DollarSign, Plus, Award, AlertTriangle, Briefcase, RefreshCw, ShoppingCart, Percent } from "lucide-react";
import { SneakerPortfolioItem, MarketSneaker, Transaction } from "../types";
import { trendingMarketSneakers } from "../data";

interface PortfolioManagerProps {
  portfolio: SneakerPortfolioItem[];
  marketSneakers: MarketSneaker[];
  currentBalance: number;
  onBuySneaker: (sneaker: MarketSneaker, size: number) => void;
  onSellSneaker: (itemId: string) => void;
  onTriggerMarketFluctuation: () => void;
}

export default function PortfolioManager({
  portfolio,
  marketSneakers,
  currentBalance,
  onBuySneaker,
  onSellSneaker,
  onTriggerMarketFluctuation
}: PortfolioManagerProps) {
  const [selectedSneaker, setSelectedSneaker] = useState<MarketSneaker | null>(null);
  const [selectedSize, setSelectedSize] = useState<number>(10);
  const [viewTab, setViewTab] = useState<"holdings" | "market">("holdings");

  // Calculate statistics
  const totalPurchaseValue = portfolio.reduce((acc, item) => acc + item.purchasePrice, 0);
  const totalMarketValue = portfolio.reduce((acc, item) => acc + item.currentPrice, 0);
  const totalProfitLoss = totalMarketValue - totalPurchaseValue;
  const percentageProfitLoss = totalPurchaseValue > 0 ? (totalProfitLoss / totalPurchaseValue) * 100 : 0;

  const standardSizes = [8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12, 13];

  const getRarityBadgeStyle = (rarity: MarketSneaker["rarity"]) => {
    switch (rarity) {
      case "Hyperstrike":
        return "bg-purple-950/45 text-purple-400 border-purple-500/30";
      case "Grail":
        return "bg-red-950/45 text-red-400 border-red-500/30";
      case "Rare":
        return "bg-sky-950/45 text-sky-400 border-sky-500/30";
      default:
        return "bg-zinc-800 text-zinc-400 border-zinc-700";
    }
  };

  const handleOpenBuyModal = (sneaker: MarketSneaker) => {
    if (currentBalance < sneaker.marketPrice) {
      alert(`❌ Insufficient Funds: This sneaker costs $${sneaker.marketPrice.toLocaleString()} but your current balance is $${currentBalance.toLocaleString()}. Deposit mock cash first!`);
      return;
    }
    setSelectedSneaker(sneaker);
    setSelectedSize(10.5); // default
  };

  const handleConfirmBuy = () => {
    if (!selectedSneaker) return;
    onBuySneaker(selectedSneaker, selectedSize);
    setSelectedSneaker(null);
  };

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md flex flex-col h-[520px]" id="portfolio-manager-module">
      {/* Module Title */}
      <div className="flex justify-between items-center mb-5 pb-3 border-b border-zinc-850">
        <div>
          <h2 className="text-sm font-mono text-zinc-500 uppercase tracking-widest">Hype wealth portfolio</h2>
          <p className="text-xs text-zinc-400 mt-1">Hedge inflation with premium deadstock assets</p>
        </div>

        <button
          onClick={onTriggerMarketFluctuation}
          className="px-3 py-1.5 rounded-full text-[10px] font-mono flex items-center gap-1.5 bg-zinc-850 hover:bg-zinc-800 text-[#d4ff3f] border border-zinc-700 hover:text-white transition-all shadow-sm cursor-pointer"
          id="trigger-hype-market-btn"
          title="Simulate sudden social media hype spike or drop"
        >
          <RefreshCw className="h-3 w-3 animate-spin-slow" />
          <span>Fluctuate Hype Market</span>
        </button>
      </div>

      {/* Portfolio Quick Stats Card */}
      <div className="grid grid-cols-3 gap-4 mb-5 p-4 rounded-2xl bg-zinc-950/65 border border-zinc-850">
        <div>
          <div className="text-[10px] font-mono text-zinc-500 uppercase">Valuation</div>
          <div className="text-lg font-mono font-bold text-zinc-100 mt-0.5" id="portfolio-valuation">
            ${totalMarketValue.toLocaleString()}
          </div>
          <div className="text-[9px] font-mono text-zinc-600">Sneaker assets</div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-zinc-500 uppercase">Acquisition Cost</div>
          <div className="text-sm font-mono font-bold text-zinc-300 mt-1">
            ${totalPurchaseValue.toLocaleString()}
          </div>
          <div className="text-[9px] font-mono text-zinc-600">All-time bought</div>
        </div>

        <div>
          <div className="text-[10px] font-mono text-zinc-500 uppercase">Unrealized profit</div>
          <div className={`text-sm font-mono font-bold flex items-center gap-1 mt-1 ${
            totalProfitLoss >= 0 ? "text-emerald-400" : "text-red-400"
          }`}>
            {totalProfitLoss >= 0 ? "+" : ""}
            ${totalProfitLoss.toLocaleString()}
          </div>
          <div className={`text-[9px] font-mono font-semibold flex items-center gap-0.5 ${
            totalProfitLoss >= 0 ? "text-emerald-500" : "text-red-500"
          }`}>
            {totalProfitLoss >= 0 ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
            <span>({percentageProfitLoss.toFixed(1)}%)</span>
          </div>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex border-b border-zinc-850 mb-4 bg-zinc-950/40 p-1 rounded-xl">
        <button
          onClick={() => setViewTab("holdings")}
          className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all ${
            viewTab === "holdings"
              ? "bg-zinc-850 text-zinc-100 shadow-sm"
              : "bg-transparent text-zinc-500 hover:text-zinc-300"
          }`}
        >
          My Sneaker Vault ({portfolio.length})
        </button>
        <button
          onClick={() => setViewTab("market")}
          className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all ${
            viewTab === "market"
              ? "bg-zinc-850 text-[#d4ff3f] shadow-sm"
              : "bg-transparent text-zinc-500 hover:text-zinc-300"
          }`}
        >
          Trending Marketplace
        </button>
      </div>

      {/* Main Tab Area */}
      <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
        <AnimatePresence mode="wait">
          {viewTab === "holdings" ? (
            <motion.div
              key="holdings"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="space-y-2.5"
            >
              {portfolio.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center border-2 border-dashed border-zinc-850 rounded-2xl bg-zinc-950/10">
                  <Briefcase className="h-8 w-8 text-zinc-700 mb-2.5" />
                  <div className="text-xs font-mono font-semibold text-zinc-400 uppercase">Vault Empty</div>
                  <p className="text-[10px] text-zinc-500 max-w-xs mt-1 leading-normal">
                    You don't hold any sneaker assets yet. Head to the **Trending Marketplace** to invest your cash into premium deadstock grails!
                  </p>
                </div>
              ) : (
                portfolio.map((item) => {
                  const gainLoss = item.currentPrice - item.purchasePrice;
                  const isGain = gainLoss >= 0;

                  return (
                    <div
                      key={item.id}
                      className="p-3 bg-zinc-950/50 border border-zinc-850 hover:border-zinc-800 rounded-xl flex items-center justify-between transition-all"
                    >
                      {/* Left Block: Shoe Icon & Title */}
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-xl shadow-inner relative">
                          <span>{item.image}</span>
                          <span className="absolute -bottom-1 -right-1 text-[8px] font-mono font-bold px-1 rounded-full bg-[#d4ff3f] text-zinc-950 border border-zinc-900">
                            US {item.size}
                          </span>
                        </div>

                        <div>
                          <h4 className="text-xs font-mono font-bold text-zinc-200 line-clamp-1">{item.name}</h4>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[9px] font-mono text-zinc-500">{item.sku}</span>
                            <span className="text-[8px] font-mono px-1.5 py-0.2 bg-zinc-800 text-zinc-400 rounded-full">
                              {item.condition}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right Block: Price Tracking & Sell */}
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-xs font-mono font-bold text-zinc-100">${item.currentPrice.toLocaleString()}</div>
                          <div className={`text-[9px] font-mono font-semibold flex items-center justify-end gap-0.5 ${
                            isGain ? "text-emerald-400" : "text-red-400"
                          }`}>
                            {isGain ? <TrendingUp className="h-2.5 w-2.5" /> : <TrendingDown className="h-2.5 w-2.5" />}
                            <span>${Math.abs(gainLoss)}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => onSellSneaker(item.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-red-950/30 hover:bg-red-950/50 text-red-400 hover:text-red-300 border border-red-900/35 text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer"
                        >
                          Sell
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </motion.div>
          ) : (
            <motion.div
              key="market"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="grid grid-cols-1 gap-2.5"
            >
              {marketSneakers.map((sneaker) => {
                const shiftValue = sneaker.marketPrice - sneaker.prevMarketPrice;
                const isPositive = shiftValue >= 0;

                return (
                  <div
                    key={sneaker.id}
                    className="p-3 bg-zinc-950/50 border border-zinc-850 hover:border-zinc-800/80 rounded-xl flex items-center justify-between transition-all"
                  >
                    {/* Left: Shoe Silhouette Visual & Info */}
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-xl shadow-inner">
                        {sneaker.image}
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="text-xs font-mono font-bold text-zinc-100">{sneaker.name}</h4>
                          <span className={`text-[8px] font-mono px-1.5 rounded border ${getRarityBadgeStyle(sneaker.rarity)}`}>
                            {sneaker.rarity}
                          </span>
                        </div>
                        <div className="text-[9px] font-mono text-zinc-500 mt-0.5">SKU: {sneaker.sku}</div>
                      </div>
                    </div>

                    {/* Right: Prices and buy Button */}
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-[#d4ff3f]">${sneaker.marketPrice.toLocaleString()}</div>
                        <div className={`text-[8px] font-mono font-semibold flex items-center justify-end gap-0.5 ${
                          isPositive ? "text-emerald-400" : "text-red-400"
                        }`}>
                          {isPositive ? "+" : ""}
                          {shiftValue} ({((shiftValue / (sneaker.prevMarketPrice || 1)) * 100).toFixed(1)}%)
                        </div>
                      </div>

                      <button
                        onClick={() => handleOpenBuyModal(sneaker)}
                        className="p-1.5 rounded-lg bg-[#d4ff3f]/10 hover:bg-[#d4ff3f]/20 border border-[#d4ff3f]/20 hover:border-[#d4ff3f]/40 text-[#d4ff3f] font-mono text-xs flex items-center justify-center transition-all cursor-pointer"
                        title="Acquire Asset"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Buy Modal (Glassmorphism backdrop Overlay) */}
      <AnimatePresence>
        {selectedSneaker && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm z-20 flex items-center justify-center p-4 rounded-3xl"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 max-w-xs w-full text-center"
            >
              <div className="w-14 h-14 rounded-full bg-zinc-950 border border-zinc-800 flex items-center justify-center text-3xl mx-auto mb-3 shadow-inner">
                {selectedSneaker.image}
              </div>

              <div className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mb-1">Confirm Investment</div>
              <h3 className="text-sm font-mono font-bold text-zinc-100 line-clamp-2 px-1 mb-2">
                {selectedSneaker.name}
              </h3>

              <div className="p-3 bg-zinc-950 rounded-xl space-y-1.5 mb-4 text-left border border-zinc-850">
                <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                  <span>Price:</span>
                  <span className="font-bold text-[#d4ff3f]">${selectedSneaker.marketPrice} USD</span>
                </div>
                <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                  <span>Your Balance:</span>
                  <span className="text-zinc-200">${currentBalance.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[11px] font-mono text-zinc-400 pt-1.5 border-t border-zinc-800">
                  <span>Select US Size:</span>
                  <div className="flex gap-1 overflow-x-auto w-2/3 scrollbar-none py-0.5 justify-end">
                    {standardSizes.map((sz) => (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => setSelectedSize(sz)}
                        className={`px-1.5 py-0.5 rounded text-[9px] font-mono shrink-0 ${
                          selectedSize === sz
                            ? "bg-[#d4ff3f] text-zinc-950 font-bold"
                            : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedSneaker(null)}
                  className="flex-1 py-2 rounded-xl bg-zinc-950 text-zinc-500 hover:text-zinc-300 font-mono text-xs uppercase border border-zinc-850 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBuy}
                  className="flex-1 py-2 rounded-xl bg-[#d4ff3f] hover:bg-lime-400 text-zinc-950 font-mono text-xs font-bold uppercase transition-all shadow-[0_0_12px_rgba(212,255,63,0.15)]"
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
