import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { TrendingUp, Plus, Goal, Calendar, CheckCircle2, ChevronRight, Landmark, Candy, Settings, Trash2 } from "lucide-react";
import { SavingsGoal } from "../types";

interface SavingsGoalsProps {
  savingsGoals: SavingsGoal[];
  gumdActive: boolean;
  onToggleGumd: () => void;
  onDepositGoal: (goalId: string, amount: number) => void;
  onAddGoal: (name: string, target: number) => void;
  onDeleteGoal: (goalId: string) => void;
  currentBalance: number;
}

export default function SavingsGoals({
  savingsGoals,
  gumdActive,
  onToggleGumd,
  onDepositGoal,
  onAddGoal,
  onDeleteGoal,
  currentBalance
}: SavingsGoalsProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newGoalName, setNewGoalName] = useState("");
  const [newGoalTarget, setNewGoalTarget] = useState("");
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState("50");

  const totalSavedInPots = savingsGoals.reduce((acc, g) => acc + g.current, 0);

  const handleSubmitGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newGoalName.trim();
    const target = parseFloat(newGoalTarget);

    if (!name || isNaN(target) || target <= 0) {
      alert("❌ Invalid goal: Provide a valid name and target value.");
      return;
    }

    onAddGoal(name, target);
    setNewGoalName("");
    setNewGoalTarget("");
    setShowAddForm(false);
  };

  const handleConfirmDeposit = () => {
    if (!depositGoalId) return;
    const amount = parseFloat(depositAmount);

    if (isNaN(amount) || amount <= 0) {
      alert("❌ Please enter a valid deposit amount.");
      return;
    }

    if (currentBalance < amount) {
      alert(`❌ Insufficient Funds: You want to deposit $${amount} but your checking balance is $${currentBalance}.`);
      return;
    }

    onDepositGoal(depositGoalId, amount);
    setDepositGoalId(null);
    setDepositAmount("50");
  };

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md flex flex-col h-[520px]" id="savings-goals-module">
      {/* Module Title */}
      <div className="flex justify-between items-center mb-5 pb-3 border-b border-zinc-850">
        <div>
          <h2 className="text-sm font-mono text-zinc-500 uppercase tracking-widest">Sole savings vault</h2>
          <p className="text-xs text-zinc-400 mt-1">Set sneaker pots & gum up spare change</p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-3 py-1.5 rounded-full text-xs font-mono flex items-center gap-1.5 bg-[#d4ff3f]/10 text-[#d4ff3f] border border-[#d4ff3f]/25 hover:bg-[#d4ff3f]/25 transition-all cursor-pointer"
          id="add-pot-btn"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>New Savings Pot</span>
        </button>
      </div>

      {/* Gumd Micro-Savings Toggle Widget */}
      <div className={`p-4 rounded-2xl bg-gradient-to-r ${
        gumdActive 
          ? "from-pink-950/40 via-purple-950/20 to-zinc-950/60 border-pink-500/30" 
          : "from-zinc-950/40 to-zinc-950 border-zinc-850"
      } border mb-5 flex items-center justify-between transition-all duration-500 relative overflow-hidden`} id="gumd-micro-savings-card">
        {/* Playful chewing gum ambient background vector */}
        <AnimatePresence>
          {gumdActive && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1.1, opacity: 0.15 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-pink-400 filter blur-xl pointer-events-none select-none"
            />
          )}
        </AnimatePresence>

        <div className="flex items-center gap-3.5 relative z-10">
          {/* Animated bouncy chewing gum bubble */}
          <motion.div
            animate={gumdActive ? { scale: [1, 1.15, 0.95, 1], rotate: [0, 5, -5, 0] } : { scale: 1 }}
            transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 border relative ${
              gumdActive 
                ? "bg-gradient-to-tr from-pink-400 to-rose-300 text-white border-pink-400/50 shadow-[0_0_15px_rgba(244,114,182,0.4)]" 
                : "bg-zinc-850 text-zinc-500 border-zinc-750"
            }`}
          >
            <Candy className={`h-6 w-6 ${gumdActive ? "animate-pulse" : ""}`} />
            {gumdActive && (
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-pink-500"></span>
              </span>
            )}
          </motion.div>

          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-mono font-bold text-zinc-200 uppercase tracking-wide">"Gumd" Micro-Savings</h4>
              <span className="text-[8px] font-mono font-extrabold px-1.5 py-0.2 bg-pink-500/10 text-pink-400 rounded-full border border-pink-500/20">
                ACTIVE 4.8% APY
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 mt-0.5 leading-normal max-w-[210px]">
              Automatically sticks spare change from checking card expenses into your active savings pots!
            </p>
          </div>
        </div>

        <button
          onClick={onToggleGumd}
          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-300 ease-in-out focus:outline-none ${
            gumdActive ? "bg-pink-500" : "bg-zinc-800"
          }`}
          id="gumd-toggle-switch"
        >
          <span className="sr-only">Toggle Gumd Micro-savings</span>
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-300 ease-in-out ${
              gumdActive ? "translate-x-5" : "translate-x-0"
            }`}
          />
        </button>
      </div>

      {/* Main Area: Add Pot Form vs Savings Pot List */}
      <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent relative">
        <AnimatePresence mode="wait">
          {showAddForm ? (
            <motion.form
              key="add-form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleSubmitGoal}
              className="p-4 bg-zinc-950/80 border border-zinc-850 rounded-2xl space-y-4"
              id="add-pot-form"
            >
              <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                <span className="text-xs font-mono font-bold text-zinc-300 uppercase">Set Up Saving Sole</span>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="text-[10px] font-mono text-zinc-500 hover:text-zinc-300"
                >
                  Cancel
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">Sneaker/Goal Title</label>
                  <input
                    type="text"
                    required
                    value={newGoalName}
                    onChange={(e) => setNewGoalName(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
                    placeholder="E.G. Jordan 1 High Union LA"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">Target Amount ($ USD)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={newGoalTarget}
                    onChange={(e) => setNewGoalTarget(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2.5 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
                    placeholder="Target price e.g. 850"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#d4ff3f] hover:bg-lime-400 text-zinc-950 font-mono text-xs font-bold uppercase transition-all shadow-sm"
              >
                Create Pot & Save
              </button>
            </motion.form>
          ) : (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-3"
            >
              {savingsGoals.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center border-2 border-dashed border-zinc-850 rounded-2xl bg-zinc-950/10">
                  <Goal className="h-8 w-8 text-zinc-700 mb-2.5" />
                  <div className="text-xs font-mono font-semibold text-zinc-400 uppercase">No Savings Pots</div>
                  <p className="text-[10px] text-zinc-500 max-w-xs mt-1 leading-normal">
                    You haven't set up any sneaker pots yet. Click **New Savings Pot** at the top right to start saving!
                  </p>
                </div>
              ) : (
                savingsGoals.map((goal) => {
                  const percentage = Math.min((goal.current / goal.target) * 100, 100);

                  return (
                    <div
                      key={goal.id}
                      className="p-4 bg-zinc-950/50 border border-zinc-850 hover:border-zinc-800 rounded-xl transition-all"
                    >
                      {/* Title row */}
                      <div className="flex justify-between items-start mb-2.5">
                        <div className="flex items-center gap-2.5">
                          <span className="text-xl shrink-0">{goal.image || "👟"}</span>
                          <div>
                            <h4 className="text-xs font-mono font-bold text-zinc-200 line-clamp-1">{goal.name}</h4>
                            <div className="flex items-center gap-1.5 mt-0.5 text-[9px] font-mono text-zinc-500">
                              <Calendar className="h-3 w-3 text-zinc-600" />
                              <span>By {goal.deadline}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setDepositGoalId(goal.id)}
                            disabled={goal.isCompleted}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-mono uppercase font-bold transition-all border shrink-0 cursor-pointer ${
                              goal.isCompleted
                                ? "bg-emerald-500/10 border-emerald-500/25 text-emerald-400 cursor-not-allowed"
                                : "bg-zinc-900 border-zinc-750 hover:border-zinc-600 text-zinc-300 hover:text-white"
                            }`}
                          >
                            {goal.isCompleted ? "COMPLETED" : "DEPOSIT"}
                          </button>

                          <button
                            onClick={() => onDeleteGoal(goal.id)}
                            className="p-1 text-zinc-700 hover:text-red-400 rounded-md hover:bg-zinc-900/60 transition-colors"
                            title="Delete pot"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Bar values */}
                      <div className="flex justify-between text-[10px] font-mono mb-1.5">
                        <span className="text-zinc-500">
                          Saved: <strong className="text-zinc-300">${goal.current}</strong> of <strong className="text-[#d4ff3f]">${goal.target}</strong>
                        </span>
                        <span className="text-zinc-400 font-bold">{percentage.toFixed(0)}%</span>
                      </div>

                      {/* Bar fill track */}
                      <div className="w-full h-2 rounded-full bg-zinc-900 border border-zinc-850 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${percentage}%` }}
                          transition={{ duration: 1, ease: "easeOut" }}
                          className={`h-full rounded-full bg-gradient-to-r ${
                            goal.isCompleted 
                              ? "from-emerald-400 to-teal-400" 
                              : "from-pink-400 via-rose-300 to-[#d4ff3f]"
                          }`}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Deposit Overlay Modal */}
      <AnimatePresence>
        {depositGoalId && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm z-20 flex items-center justify-center p-4 rounded-3xl"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 max-w-xs w-full text-center"
            >
              <div className="w-12 h-12 rounded-full bg-zinc-950 border border-zinc-800 flex items-center justify-center text-xl mx-auto mb-3 text-[#d4ff3f] shadow-inner">
                <Landmark className="h-6 w-6" />
              </div>

              <div className="text-zinc-500 text-[10px] font-mono uppercase tracking-widest mb-1">Transfer to savings</div>
              <h3 className="text-xs font-mono font-bold text-zinc-100 mb-4">
                Securely Cushioning Your Soles
              </h3>

              <div className="space-y-4 text-left">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">Deposit Amount ($ USD)</label>
                  <input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700"
                    placeholder="Enter deposit amount e.g. 50"
                  />
                  <div className="text-[9px] font-mono text-zinc-600">
                    Checking Balance: ${currentBalance.toLocaleString()}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {["25", "50", "100"].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setDepositAmount(preset)}
                      className={`py-1 rounded text-[10px] font-mono ${
                        depositAmount === preset
                          ? "bg-zinc-800 text-[#d4ff3f] border border-zinc-750 font-bold"
                          : "bg-zinc-950 text-zinc-500 border border-zinc-900 hover:border-zinc-800"
                      }`}
                    >
                      +${preset}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 mt-5">
                <button
                  type="button"
                  onClick={() => setDepositGoalId(null)}
                  className="flex-1 py-2 rounded-xl bg-zinc-950 text-zinc-500 hover:text-zinc-300 font-mono text-xs uppercase border border-zinc-850 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeposit}
                  className="flex-1 py-2 rounded-xl bg-[#d4ff3f] hover:bg-lime-400 text-zinc-950 font-mono text-xs font-bold uppercase transition-all shadow-[0_0_12px_rgba(212,255,63,0.15)]"
                >
                  Deposit
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
