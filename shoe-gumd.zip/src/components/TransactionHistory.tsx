import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, TrendingUp, DollarSign, Plus, ArrowUpRight, ArrowDownLeft, Flame, Candy, ShoppingBag, Coins, RefreshCw } from "lucide-react";
import { Transaction } from "../types";

interface TransactionHistoryProps {
  transactions: Transaction[];
  onTransfer: (handle: string, amount: number, description: string) => void;
  onDeposit: (amount: number) => void;
  currentBalance: number;
}

export default function TransactionHistory({
  transactions,
  onTransfer,
  onDeposit,
  currentBalance
}: TransactionHistoryProps) {
  const [showTransferForm, setShowTransferForm] = useState(false);
  const [recipient, setRecipient] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferDesc, setTransferDesc] = useState("");

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let handle = recipient.trim();
    const amount = parseFloat(transferAmount);
    const desc = transferDesc.trim() || "Peer Transfer";

    if (!handle.startsWith("@")) {
      handle = "@" + handle;
    }

    if (handle.length < 3 || isNaN(amount) || amount <= 0) {
      alert("❌ Invalid transfer parameters. Provide a valid username handle and transfer amount.");
      return;
    }

    if (currentBalance < amount) {
      alert(`❌ Insufficient Funds: Your transfer of $${amount} exceeds your checking balance of $${currentBalance}.`);
      return;
    }

    onTransfer(handle, amount, desc);
    setRecipient("");
    setTransferAmount("");
    setTransferDesc("");
    setShowTransferForm(false);
  };

  const getCategoryIcon = (category: Transaction["category"]) => {
    switch (category) {
      case "grails":
        return <Flame className="h-4 w-4 text-orange-400" />;
      case "retail":
        return <ShoppingBag className="h-4 w-4 text-sky-400" />;
      case "gumd_saved":
        return <Candy className="h-4 w-4 text-pink-400" />;
      case "transfer":
        return <Send className="h-4 w-4 text-purple-400" />;
      case "deposit":
        return <Coins className="h-4 w-4 text-[#d4ff3f]" />;
      default:
        return <DollarSign className="h-4 w-4 text-zinc-400" />;
    }
  };

  const getCategoryLabel = (category: Transaction["category"]) => {
    switch (category) {
      case "grails":
        return "Grails Purchase";
      case "retail":
        return "Retail Store";
      case "gumd_saved":
        return "Gumd Micro-Saved";
      case "transfer":
        return "Peer Transfer";
      case "deposit":
        return "Cash Deposit";
      default:
        return "General";
    }
  };

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md flex flex-col h-[520px]" id="transaction-history-module">
      {/* Header */}
      <div className="flex justify-between items-center mb-5 pb-3 border-b border-zinc-850">
        <div>
          <h2 className="text-sm font-mono text-zinc-500 uppercase tracking-widest">Transaction ledger</h2>
          <p className="text-xs text-zinc-400 mt-1">Real-time boutique checking log</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTransferForm(!showTransferForm)}
            className="px-3 py-1.5 rounded-full text-xs font-mono flex items-center gap-1.5 bg-zinc-850 hover:bg-zinc-800 text-zinc-200 border border-zinc-750 transition-all cursor-pointer"
            id="open-transfer-form-btn"
          >
            <Send className="h-3.5 w-3.5" />
            <span>Transfer P2P</span>
          </button>
        </div>
      </div>

      {/* Instant Deposit Quickbar */}
      <div className="p-3.5 rounded-2xl bg-zinc-950/65 border border-zinc-850 mb-4">
        <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-wide mb-2 flex items-center gap-1">
          <Coins className="h-3 w-3 text-[#d4ff3f]" />
          <span>Simulate Cash Deposit (Test Funds)</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[200, 1000, 5000].map((val) => (
            <button
              key={val}
              onClick={() => onDeposit(val)}
              className="py-1.5 rounded-xl bg-[#d4ff3f]/10 hover:bg-[#d4ff3f]/25 border border-[#d4ff3f]/20 hover:border-[#d4ff3f]/40 text-[#d4ff3f] text-xs font-mono font-bold transition-all cursor-pointer"
            >
              +${val.toLocaleString()}
            </button>
          ))}
        </div>
      </div>

      {/* Main Area: Transfer Form vs Ledger list */}
      <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent relative">
        <AnimatePresence mode="wait">
          {showTransferForm ? (
            <motion.form
              key="transfer-form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              onSubmit={handleTransferSubmit}
              className="p-4 bg-zinc-950/80 border border-zinc-850 rounded-2xl space-y-4"
              id="peer-transfer-form"
            >
              <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                <span className="text-xs font-mono font-bold text-zinc-300 uppercase">Peer-to-Peer Transfer</span>
                <button
                  type="button"
                  onClick={() => setShowTransferForm(false)}
                  className="text-[10px] font-mono text-zinc-500 hover:text-zinc-300"
                >
                  Cancel
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">RECIPIENT HANDLE</label>
                  <input
                    type="text"
                    required
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
                    placeholder="@hype_kicks"
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">AMOUNT ($ USD)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
                    placeholder="Value to transfer"
                  />
                  <div className="text-[9px] font-mono text-zinc-600">
                    Checking Balance: ${currentBalance.toLocaleString()}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-zinc-500 uppercase">REFERENCE / MEMO</label>
                  <input
                    type="text"
                    value={transferDesc}
                    onChange={(e) => setTransferDesc(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
                    placeholder="E.G. Paid for Off-White laces"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#d4ff3f] hover:bg-lime-400 text-zinc-950 font-mono text-xs font-bold uppercase transition-all shadow-sm"
              >
                Send Money
              </button>
            </motion.form>
          ) : (
            <motion.div
              key="ledger"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-2.5"
            >
              {transactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <div className="text-xs font-mono font-semibold text-zinc-400 uppercase">No history</div>
                  <p className="text-[10px] text-zinc-500 max-w-xs mt-1">No transaction records detected.</p>
                </div>
              ) : (
                transactions.map((tx) => {
                  const isExpense = tx.type === "expense";

                  return (
                    <div
                      key={tx.id}
                      className="p-3 bg-zinc-950/45 border border-zinc-850 hover:border-zinc-800/80 rounded-xl flex items-center justify-between transition-all"
                    >
                      {/* Left side: Icons and Category labels */}
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${
                          isExpense 
                            ? "bg-zinc-900 border-zinc-800" 
                            : "bg-emerald-950/35 border-emerald-900/30"
                        }`}>
                          {getCategoryIcon(tx.category)}
                        </div>

                        <div>
                          <h4 className="text-xs font-mono font-bold text-zinc-200 line-clamp-1">{tx.description}</h4>
                          <div className="flex items-center gap-1.5 mt-0.5 text-[9px] font-mono text-zinc-500">
                            <span>{getCategoryLabel(tx.category)}</span>
                            <span>•</span>
                            <span>{tx.date}</span>
                          </div>
                        </div>
                      </div>

                      {/* Right side: Amount and indicators */}
                      <div className="text-right">
                        <div className={`text-xs font-mono font-bold ${
                          isExpense ? "text-zinc-300" : "text-emerald-400"
                        }`}>
                          {isExpense ? "-" : "+"}
                          ${tx.amount.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
                        </div>
                        {tx.shoeModel && (
                          <div className="text-[8px] font-mono text-[#d4ff3f] mt-0.5 max-w-[80px] truncate">
                            {tx.shoeModel}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
