import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Send, Sparkles, User, RefreshCw, X, HelpCircle, ArrowRight } from "lucide-react";
import { ChatMessage } from "../types";

interface SoleAdvisorProps {
  currentBalance: number;
  portfolioValue: number;
  savingGoalsCount: number;
}

export default function SoleAdvisor({ currentBalance, portfolioValue, savingGoalsCount }: SoleAdvisorProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "model",
      text: "Yo! I'm **SoleAdvisor**, your personal AI sneaker-finance consultant. I help you lace up your budgets, stick to your saving goals, and navigate the volatile world of grail investing without stepping in gum.\n\nHow's your financial cushion feeling today? Ask me anything about budgeting, saving, or sneaker asset portfolios!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadingTexts = [
    "Pumping up the cushioning...",
    "Sticking the gum-change budget...",
    "Lacing up financial models...",
    "Checking sneaker resale valuations...",
    "Polishing the outsoles..."
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % loadingTexts.length);
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const userText = textToSend || input.trim();
    if (!userText || isLoading) return;

    if (!textToSend) setInput("");

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}-user`,
      role: "user",
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setIsLoading(true);
    setLoadingStep(0);

    try {
      // Inject some real-time context into the chat sequence privately so SoleAdvisor has accurate awareness of their bank account
      const contextMessage = {
        role: "user" as const,
        text: `[SYSTEM CONTEXT: The user currently has a liquid balance of $${currentBalance.toLocaleString()} USD in their ShoeGumd checking account, a sneaker asset portfolio valued at $${portfolioValue.toLocaleString()} USD, and they have ${savingGoalsCount} active Sole Saving Goals. Keep these numbers in mind if they ask about their wealth or budgets, but keep the explanation natural and conversational.]`
      };

      // We send the messages including the user context, but we don't display the system context in the frontend chat log.
      const payloadMessages = [
        ...messages.map(m => ({ role: m.role, text: m.text })),
        contextMessage,
        { role: "user" as const, text: userText }
      ];

      const response = await fetch("/api/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: payloadMessages })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to fetch response.");
      }

      const data = await response.json();

      const aiMessage: ChatMessage = {
        id: `msg-${Date.now()}-ai`,
        role: "model",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      console.error(err);
      const errorMessage: ChatMessage = {
        id: `msg-${Date.now()}-err`,
        role: "model",
        text: `⚠️ **SoleAdvisor offline:** ${err.message || "Failed to make advice contact."}\n\nPlease check if your Gemini API Key is configured in the AI Studio Secrets panel.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestions = [
    { label: "Check Portfolio Risk", text: "What is the liquidity and market risk of storing my wealth in a deadstock sneaker portfolio?" },
    { label: "Gumd Micro-savings Plan", text: "How can I set up an automated plan using Gumd micro-savings to buy a $1,250 Jordan Chicago?" },
    { label: "Lace Me with a Pun", text: "Give me some clever shoe-themed financial advice with puns!" },
    { label: "Am I Hypebeast Broke?", text: "I have a $1,500 balance and want to buy two pairs of Yeezys. Analyze my budget and tell me if I'm spending responsibly." }
  ];

  // Robust custom markdown parser helper
  const parseMarkdown = (rawText: string) => {
    const lines = rawText.split("\n");
    return lines.map((line, i) => {
      // Bullet lists
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const content = line.trim().substring(2);
        return (
          <li key={i} className="ml-4 list-disc text-xs text-zinc-300 leading-relaxed mb-1 font-sans">
            {renderBoldText(content)}
          </li>
        );
      }
      
      // Standard line formatting
      if (line.trim() === "") {
        return <div key={i} className="h-2"></div>;
      }

      return (
        <p key={i} className="text-xs text-zinc-300 leading-relaxed mb-2 font-sans">
          {renderBoldText(line)}
        </p>
      );
    });
  };

  const renderBoldText = (text: string) => {
    // Regex matches **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        return (
          <strong key={index} className="font-semibold text-zinc-100 font-sans">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  const clearChat = () => {
    setMessages([
      {
        id: "welcome-reset",
        role: "model",
        text: "Clean slate! The outsoles are scrubbed and we are ready for a new financial run. Ask me anything!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md flex flex-col h-[520px]" id="sole-advisor-bot">
      {/* Advisor Header */}
      <div className="flex justify-between items-center border-b border-zinc-850 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#d4ff3f] to-lime-400 flex items-center justify-center text-zinc-950 font-bold shadow-[0_0_12px_rgba(212,255,63,0.3)]">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm font-mono font-bold text-zinc-100 tracking-wider">SoleAdvisor</h2>
              <span className="text-[9px] px-1.5 py-0.5 bg-zinc-800 text-[#d4ff3f] font-mono rounded border border-zinc-700/60 font-extrabold uppercase animate-pulse">
                Gemini AI
              </span>
            </div>
            <p className="text-[10px] text-zinc-500 font-mono">Personal Sneaker-Finance Consultant</p>
          </div>
        </div>

        <button 
          onClick={clearChat}
          className="text-zinc-600 hover:text-zinc-400 p-1.5 rounded-lg hover:bg-zinc-850 transition-colors"
          title="Reset Advisor Conversation"
        >
          <RefreshCw className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Message Area */}
      <div className="flex-1 overflow-y-auto pr-2 space-y-4 mb-4 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-2 max-w-[85%] ${m.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
          >
            {/* Avatar */}
            <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 text-[10px] ${
              m.role === "user" 
                ? "bg-zinc-800 text-zinc-300 border border-zinc-700" 
                : "bg-[#d4ff3f]/10 text-[#d4ff3f] border border-[#d4ff3f]/20"
            }`}>
              {m.role === "user" ? <User className="h-3.5 w-3.5" /> : "👟"}
            </div>

            <div className="flex flex-col gap-1">
              <div className={`rounded-2xl px-3.5 py-2.5 ${
                m.role === "user" 
                  ? "bg-zinc-800 text-zinc-100 rounded-tr-none" 
                  : "bg-zinc-950/60 border border-zinc-850 text-zinc-300 rounded-tl-none"
              }`}>
                {parseMarkdown(m.text)}
              </div>
              <span className={`text-[8px] font-mono text-zinc-600 ${m.role === "user" ? "text-right" : "text-left"}`}>
                {m.timestamp}
              </span>
            </div>
          </div>
        ))}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex gap-2 mr-auto max-w-[85%]">
            <div className="w-6 h-6 rounded-lg bg-[#d4ff3f]/10 text-[#d4ff3f] border border-[#d4ff3f]/20 flex items-center justify-center text-[10px] animate-bounce">
              👟
            </div>
            <div className="bg-zinc-950/60 border border-zinc-850 rounded-2xl px-3.5 py-2.5 rounded-tl-none text-xs text-zinc-400 font-mono flex items-center gap-2">
              <RefreshCw className="h-3 w-3 animate-spin text-[#d4ff3f]" />
              <span>{loadingTexts[loadingStep]}</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggestions Tray */}
      {messages.length === 1 && (
        <div className="mb-4">
          <p className="text-[10px] font-mono text-zinc-500 mb-1.5 uppercase tracking-wider flex items-center gap-1">
            <HelpCircle className="h-3 w-3" />
            <span>Try asking SoleAdvisor:</span>
          </p>
          <div className="grid grid-cols-2 gap-1.5">
            {suggestions.map((s, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(s.text)}
                className="p-2 rounded-xl bg-zinc-950/40 border border-zinc-850 hover:border-zinc-700/80 hover:bg-zinc-900/60 text-left text-[10px] text-zinc-400 hover:text-zinc-200 transition-all font-mono line-clamp-2"
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center gap-2 mt-auto"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isLoading}
          className="flex-1 bg-zinc-950/80 border border-zinc-850 rounded-xl px-4 py-3 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700 disabled:opacity-50"
          placeholder={isLoading ? "SoleAdvisor is calculating..." : "Ask how to cushion your asset soles..."}
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="h-10 w-10 shrink-0 bg-[#d4ff3f] hover:bg-lime-400 disabled:bg-zinc-800 disabled:text-zinc-600 text-zinc-950 rounded-xl flex items-center justify-center transition-all shadow-[0_0_12px_rgba(212,255,63,0.15)] hover:shadow-[0_0_15px_rgba(212,255,63,0.3)] cursor-pointer"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
