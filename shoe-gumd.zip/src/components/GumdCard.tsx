import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Eye, EyeOff, Snowflake, Shield, Sparkles, RefreshCw } from "lucide-react";

interface GumdCardProps {
  cardHolder: string;
  isFrozen: boolean;
  onToggleFreeze: () => void;
  balance: number;
}

export default function GumdCard({ cardHolder, isFrozen, onToggleFreeze, balance }: GumdCardProps) {
  const [showNumber, setShowNumber] = useState(false);
  const [cardTheme, setCardTheme] = useState<"volt" | "carbon" | "crimson" | "bubblegum">("volt");
  const [laceColor, setLaceColor] = useState<"volt" | "cream" | "red" | "black">("volt");
  const [laserText, setLaserText] = useState("NOT FOR RESALE");

  const themes = {
    volt: {
      bg: "bg-gradient-to-br from-zinc-900 via-stone-900 to-zinc-950",
      accent: "text-[#d4ff3f]",
      border: "border-zinc-800/80",
      glow: "shadow-[0_0_20px_rgba(212,255,63,0.15)]",
      stripe: "bg-[#d4ff3f]/10 text-[#d4ff3f]",
      pill: "bg-[#d4ff3f]"
    },
    carbon: {
      bg: "bg-gradient-to-br from-zinc-950 via-neutral-900 to-zinc-900",
      accent: "text-zinc-100",
      border: "border-zinc-700/60",
      glow: "shadow-[0_0_20px_rgba(255,255,255,0.05)]",
      stripe: "bg-zinc-800 text-zinc-300",
      pill: "bg-zinc-200"
    },
    crimson: {
      bg: "bg-gradient-to-br from-zinc-900 via-rose-950 to-zinc-950",
      accent: "text-red-500",
      border: "border-red-900/40",
      glow: "shadow-[0_0_20px_rgba(239,68,68,0.15)]",
      stripe: "bg-red-950/40 text-red-400",
      pill: "bg-red-500"
    },
    bubblegum: {
      bg: "bg-gradient-to-br from-stone-900 via-pink-950/60 to-zinc-950",
      accent: "text-pink-400",
      border: "border-pink-900/30",
      glow: "shadow-[0_0_20px_rgba(244,114,182,0.15)]",
      stripe: "bg-pink-950/30 text-pink-300",
      pill: "bg-pink-400"
    }
  };

  const laces = {
    volt: "stroke-[#d4ff3f]",
    cream: "stroke-[#fdf6e2]",
    red: "stroke-red-500",
    black: "stroke-zinc-400"
  };

  const activeTheme = themes[cardTheme];

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-6 backdrop-blur-md" id="gumd-card-module">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-sm font-mono text-zinc-500 uppercase tracking-widest">ShoeGumd Premium Card</h2>
          <p className="text-xs text-zinc-400 mt-1">Laced with high-interest saving soles</p>
        </div>
        <button
          onClick={onToggleFreeze}
          className={`px-3 py-1.5 rounded-full text-xs font-mono flex items-center gap-1.5 transition-all ${
            isFrozen
              ? "bg-sky-500/20 text-sky-400 border border-sky-500/30 shadow-[0_0_12px_rgba(14,165,233,0.2)]"
              : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-zinc-200"
          }`}
          id="freeze-card-btn"
        >
          {isFrozen ? (
            <>
              <Snowflake className="h-3 w-3 animate-spin" />
              <span>Card Frozen</span>
            </>
          ) : (
            <>
              <Shield className="h-3 w-3" />
              <span>Freeze Card</span>
            </>
          )}
        </button>
      </div>

      {/* Real Card Frame */}
      <div className="relative aspect-[1.586/1] w-full max-w-sm mx-auto mb-6 perspective-1000">
        <motion.div
          animate={isFrozen ? { scale: 0.98, rotateX: 3, rotateY: -3 } : { scale: 1, rotateX: 0, rotateY: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className={`w-full h-full rounded-2xl p-6 flex flex-col justify-between relative overflow-hidden border ${activeTheme.bg} ${activeTheme.border} ${activeTheme.glow} transition-all duration-500`}
          id="physical-card-canvas"
        >
          {/* Sneaker Aesthetic: Lace Graphic Background */}
          <div className="absolute right-0 top-0 w-1/2 h-full opacity-20 pointer-events-none select-none">
            <svg viewBox="0 0 100 150" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
              {/* Left Eyelets */}
              <circle cx="20" cy="20" r="4" fill="#3f3f46" />
              <circle cx="20" cy="50" r="4" fill="#3f3f46" />
              <circle cx="20" cy="80" r="4" fill="#3f3f46" />
              <circle cx="20" cy="110" r="4" fill="#3f3f46" />

              {/* Right Eyelets */}
              <circle cx="80" cy="20" r="4" fill="#3f3f46" />
              <circle cx="80" cy="50" r="4" fill="#3f3f46" />
              <circle cx="80" cy="80" r="4" fill="#3f3f46" />
              <circle cx="80" cy="110" r="4" fill="#3f3f46" />

              {/* Lacing path */}
              <path d="M 20 20 L 80 50 M 80 20 L 20 50 M 20 50 L 80 80 M 80 50 L 20 80 M 20 80 L 80 110 M 80 80 L 20 110" 
                className={`stroke-2 ${laces[laceColor]} transition-colors duration-500`} 
              />
            </svg>
          </div>

          {/* Holographic Gum Dot at top-right */}
          <div className="absolute top-6 right-6 flex items-center gap-1.5">
            <div className="text-[10px] font-mono tracking-widest text-zinc-500 mr-1 select-none">SG</div>
            <div className={`w-8 h-8 rounded-full bg-gradient-to-tr from-pink-400 via-purple-400 to-[#d4ff3f] opacity-85 shadow-inner relative flex items-center justify-center`}>
              <div className="absolute inset-1 rounded-full bg-black/10 backdrop-blur-[1px]"></div>
              <Sparkles className="h-3 w-3 text-white absolute" />
            </div>
          </div>

          {/* Chip & Logo */}
          <div className="flex justify-between items-start">
            <div className="flex flex-col gap-2">
              {/* Chip Visual */}
              <div className="w-10 h-8 rounded bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 border border-amber-400/30 flex flex-col justify-between p-1.5">
                <div className="flex justify-between h-2 border-b border-amber-900/10">
                  <div className="w-2 bg-amber-950/20"></div>
                  <div className="w-2 bg-amber-950/20"></div>
                </div>
                <div className="w-full h-1.5 bg-amber-950/10 rounded-sm"></div>
                <div className="flex justify-between h-2">
                  <div className="w-2 bg-amber-950/20"></div>
                  <div className="w-2 bg-amber-950/20"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Card Number */}
          <div className="my-2">
            <div className="flex items-center gap-2">
              <span className={`font-mono text-base tracking-[0.2em] text-zinc-100`}>
                {showNumber ? "4532 •••• •••• 9812" : "•••• •••• •••• 9812"}
              </span>
              <button 
                onClick={() => setShowNumber(!showNumber)}
                className="text-zinc-500 hover:text-zinc-300 p-1"
                title="Toggle Card Number"
              >
                {showNumber ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* Laser-engraved Outsole Text & Card Holder */}
          <div className="flex justify-between items-end">
            <div className="flex flex-col">
              <div className="text-[9px] font-mono text-zinc-500 uppercase tracking-wider">Laced For</div>
              <span className="font-mono text-sm font-semibold text-zinc-200 tracking-wider">
                {cardHolder || "HYPEBEAST ONE"}
              </span>
            </div>

            <div className="text-right">
              {/* Outsole Laser text mimicking off-white stamp style */}
              <div className={`font-mono text-[9px] px-2 py-0.5 rounded ${activeTheme.stripe} inline-block font-extrabold uppercase tracking-wider select-none border border-current/20`}>
                "{laserText || "NOT FOR RESALE"}"
              </div>
            </div>
          </div>

          {/* Frozen Ice Sheet Overlay */}
          <AnimatePresence>
            {isFrozen && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-sky-950/70 backdrop-blur-sm flex flex-col justify-center items-center gap-2 z-10"
              >
                <motion.div
                  initial={{ scale: 0.5, rotate: -45 }}
                  animate={{ scale: 1, rotate: 0 }}
                  className="w-12 h-12 rounded-full bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-300 shadow-[0_0_15px_rgba(14,165,233,0.3)]"
                >
                  <Snowflake className="h-6 w-6 animate-pulse" />
                </motion.div>
                <div className="text-center">
                  <div className="text-xs font-mono font-bold text-sky-200 uppercase tracking-widest">SHOEGUMD frozen</div>
                  <div className="text-[10px] font-mono text-sky-400 mt-0.5">Defrost in app panel to spend</div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Customizer Panel */}
      <div className="space-y-4 border-t border-zinc-800/80 pt-4" id="card-customizer">
        <h3 className="text-xs font-mono font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="h-3 w-3 text-[#d4ff3f]" />
          <span>Card Lace & Customizer</span>
        </h3>

        {/* Theme Selector */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] font-mono text-zinc-500">SOLE THEME</label>
          <div className="grid grid-cols-4 gap-2">
            {(["volt", "carbon", "crimson", "bubblegum"] as const).map((theme) => (
              <button
                key={theme}
                onClick={() => setCardTheme(theme)}
                className={`px-2 py-1.5 rounded-lg text-xs font-mono border capitalize transition-all ${
                  cardTheme === theme
                    ? "bg-zinc-800 text-zinc-100 border-zinc-600 shadow-sm"
                    : "bg-zinc-950/40 text-zinc-500 border-zinc-900 hover:border-zinc-800 hover:text-zinc-400"
                }`}
              >
                {theme}
              </button>
            ))}
          </div>
        </div>

        {/* Lace Style Selector */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] font-mono text-zinc-500">LACE STYLE</label>
          <div className="grid grid-cols-4 gap-2">
            {(["volt", "cream", "red", "black"] as const).map((color) => (
              <button
                key={color}
                onClick={() => setLaceColor(color)}
                className={`px-2 py-1.5 rounded-lg text-xs font-mono border capitalize transition-all ${
                  laceColor === color
                    ? "bg-zinc-800 text-zinc-100 border-zinc-600 shadow-sm"
                    : "bg-zinc-950/40 text-zinc-500 border-zinc-900 hover:border-zinc-800 hover:text-zinc-400"
                }`}
              >
                {color}
              </button>
            ))}
          </div>
        </div>

        {/* Laser Engraving Outsole Text */}
        <div className="flex flex-col gap-1.5">
          <label className="text-[11px] font-mono text-zinc-500 flex justify-between">
            <span>OUTSOLE STAMP TEXT</span>
            <span>{laserText.length}/18</span>
          </label>
          <input
            type="text"
            value={laserText}
            onChange={(e) => setLaserText(e.target.value.toUpperCase().slice(0, 18))}
            className="w-full bg-zinc-950/80 border border-zinc-850 rounded-xl px-3 py-2 text-xs font-mono text-zinc-100 focus:outline-none focus:border-zinc-700 placeholder-zinc-700"
            placeholder='E.G., "NOT FOR RESALE"'
          />
        </div>
      </div>
    </div>
  );
}
